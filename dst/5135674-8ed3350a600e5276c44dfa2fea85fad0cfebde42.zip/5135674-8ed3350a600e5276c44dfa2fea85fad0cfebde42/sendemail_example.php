<?php
require_once '/path_to_swift/lib/swift_required.php';
require_once 'SendEMail.php';

$sm = new SendEMail();

$recipients[0] = array(
    'email'           => 'onotole@blabla.com',
	'user'            => 'Onotole',
	'something'       => 'myalka',
	'something_photo' => 'myalka.jpg',
	'templateDir'     => 'second_template'
);
$recipients[1] = array(
	'email'           => 'volodya@blabla.com',
	'user'            => 'Genade',
	'something'       => 'meshalka',
	'something_photo' => 'meshalka.jpg',
	'templateDir'     => 'first_template'
);

$sm->templatesPath = "/path_to_templates";
$sm->emailFrom = 'noreply@site.com';
$sm->fromName = 'Site.com';

$count = 0;
foreach($recipients as $rec) {
	$sm->varData = array(
		'{user}' => $rec['user'],
		'{something}' => $rec['something'],
		'{something_photo}' => $rec['something_photo']
	);
	$sm->emailTo = $rec['email'];
	$sm->toName = $rec['user'];
	$sm->templateDirname = $rec['templateDir'];
	if ($sm->Send())
		$count++;
}

echo $count." email(-s) have been sent.";