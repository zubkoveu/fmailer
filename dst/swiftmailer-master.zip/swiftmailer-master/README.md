Swift Mailer
------------

Swift Mailer is a component based mailing solution for PHP.
It is released under the MIT license.

Swift Mailer is highly object-oriented by design and lends itself
to use in complex web application with a great deal of flexibility.

For full details on usage, read the [documentation](https://swiftmailer.symfony.com/docs/introduction.html).

Sponsors
--------

<div>
    <a href="https://blackfire.io/docs/introduction?utm_source=swiftmailer&utm_medium=github_readme&utm_campaign=logo">
        <img src="https://static.blackfire.io/assets/intemporals/logo/png/blackfire-io_secondary_horizontal_transparent.png?1" width="255px" alt="Blackfire.io">
    </a>
</div>
